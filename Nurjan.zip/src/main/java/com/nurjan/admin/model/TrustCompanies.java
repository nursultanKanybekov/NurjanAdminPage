package com.nurjan.admin.model;

public class TrustCompanies {
    private String link;
    private String image;
    private String key;

    public TrustCompanies(String link, String image, String key) {
        this.link = link;
        this.image = image;
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
