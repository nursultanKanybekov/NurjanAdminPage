package com.nurjan.admin.model;

public class ExperienceModel {
    private String year;
    private String company;
    private String position;
    private String certificates;

    public ExperienceModel(String year, String company, String position, String certificates) {
        this.year = year;
        this.company = company;
        this.position = position;
        this.certificates = certificates;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getCertificates() {
        return certificates;
    }

    public void setCertificates(String certificates) {
        this.certificates = certificates;
    }

    private String key;
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
