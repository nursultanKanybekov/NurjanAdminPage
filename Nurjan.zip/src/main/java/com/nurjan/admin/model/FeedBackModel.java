package com.nurjan.admin.model;

public class FeedBackModel {
    private String image;
    private String name;
    private String feedback;

    private String key;

    public FeedBackModel(String image, String name, String feedback) {
        this.image = image;
        this.name = name;
        this.feedback = feedback;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
