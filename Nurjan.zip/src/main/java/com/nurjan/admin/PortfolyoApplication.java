package com.nurjan.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolyoApplication {

    public static void main(String[] args) {
//        try {
//            TelegramBotsApi telegramBotsApi = new TelegramBotsApi(DefaultBotSession.class);
//            telegramBotsApi.registerBot(new TelegramBotService());
//        } catch (TelegramApiException e) {
//            e.printStackTrace();
//        }
        SpringApplication.run(PortfolyoApplication.class, args);
    }

}
