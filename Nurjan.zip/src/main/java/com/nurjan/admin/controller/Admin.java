package com.nurjan.admin.controller;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nurjan.admin.model.*;
import com.nurjan.admin.service.CloudinaryService;
import com.nurjan.admin.service.FirebaseServices;
import com.nurjan.admin.service.StringService;
import com.nurskanyb.portfolyo.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
public class Admin {
    @Autowired
    private FirebaseServices firebaseServices;
    private final StringService stringService = new StringService();
    private final CloudinaryService cloudinaryConfig = new CloudinaryService();

    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public String mainPageG(Model model) {
        CompletableFuture<List<Object>> experience = firebaseServices.getOptionsFromFirebase("experience");
        CompletableFuture<List<Object>> feedback = firebaseServices.getOptionsFromFirebase("feedback");
        CompletableFuture<List<Object>> interestedIn = firebaseServices.getOptionsFromFirebase("interestedIn");
        CompletableFuture<List<Object>> portfolyo = firebaseServices.getOptionsFromFirebase("portfolyo");
        CompletableFuture<List<Object>> skill = firebaseServices.getOptionsFromFirebase("skill");
        try {
            CompletableFuture.allOf(experience, feedback, interestedIn, portfolyo, skill).join();

            List<Object> experienceList = experience.get();
            List<Object> feedbackList = feedback.get();
            List<Object> interestedInList = interestedIn.get();
            List<Object> portfolyoList = portfolyo.get();
            List<Object> skillList = skill.get();

            model.addAttribute("experienceList", experienceList);
            model.addAttribute("feedbackList", feedbackList);
            model.addAttribute("interestedInList", interestedInList);
            model.addAttribute("portfolyoList", portfolyoList);
            model.addAttribute("skillList", skillList);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return "admin";
    }

    @RequestMapping(value = "/admin_experience", method = RequestMethod.POST)
    public String experience(@ModelAttribute ExperienceModel experienceModel, @RequestParam("file") MultipartFile file) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("experience");
        experienceModel.setKey(ref.push().getKey());
        if (!file.isEmpty())
            experienceModel.setCertificates(cloudinaryConfig.imageUploadCloudinary(null, file.getBytes()));
        else
            experienceModel.setCertificates(cloudinaryConfig.imageUploadCloudinary(experienceModel.getCertificates(), null));
        firebaseServices.saveFirebase(experienceModel, ref, experienceModel.getKey());
        return "admin";
    }

    @RequestMapping(value = "/admin_feedback", method = RequestMethod.POST)
    public String feedback(@ModelAttribute FeedBackModel feedBackModel, @RequestParam("file") MultipartFile file) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("feedback");
        feedBackModel.setKey(ref.push().getKey());
        if (!file.isEmpty())
            feedBackModel.setImage(cloudinaryConfig.imageUploadCloudinary(null, file.getBytes()));
        else
            feedBackModel.setImage(cloudinaryConfig.imageUploadCloudinary(feedBackModel.getImage(), null));
        firebaseServices.saveFirebase(feedBackModel, ref, feedBackModel.getKey());
        return "admin";
    }

    @RequestMapping(value = "/admin_interestedIN", method = RequestMethod.POST)
    public String interestedIN(@ModelAttribute InterestedIn interestedIn, @RequestParam("file") MultipartFile file) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("interestedIn");
        interestedIn.setKey(ref.push().getKey());
        if (!file.isEmpty())
            interestedIn.setLink(cloudinaryConfig.imageUploadCloudinary(null, file.getBytes()));
        else
            interestedIn.setLink(cloudinaryConfig.imageUploadCloudinary(interestedIn.getLink(), null));
        firebaseServices.saveFirebase(interestedIn, ref, interestedIn.getKey());
        return "admin";
    }

    @RequestMapping(value = "/admin_portfolyo", method = RequestMethod.POST)
    public String portfolyo(@ModelAttribute PortfolyoModel portfolyoModel, @RequestParam("file") MultipartFile file) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("portfolyo");
        portfolyoModel.setKey(ref.push().getKey());
        if (!file.isEmpty())
            portfolyoModel.setImage(cloudinaryConfig.imageUploadCloudinary(null, file.getBytes()));
        else
            portfolyoModel.setImage(cloudinaryConfig.imageUploadCloudinary(portfolyoModel.getImage(), null));
        firebaseServices.saveFirebase(portfolyoModel, ref, portfolyoModel.getKey());
        return "admin";
    }

    @RequestMapping(value = "/admin_skill", method = RequestMethod.POST)
    public String skill(@ModelAttribute SkillModel skillModel) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("skill");
        skillModel.setKey(ref.push().getKey());
        firebaseServices.saveFirebase(skillModel, ref, skillModel.getKey());

        return "admin";
    }

    @RequestMapping(value = "/admin_trust_companies", method = RequestMethod.POST)
    public String trustCompanies(@ModelAttribute TrustCompanies trustCompanies, @RequestParam("file") MultipartFile file) throws IOException {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("trust_companies");
        trustCompanies.setKey(ref.push().getKey());
        if (!file.isEmpty())
            trustCompanies.setImage(cloudinaryConfig.imageUploadCloudinary(null, file.getBytes()));
        else
            trustCompanies.setImage(cloudinaryConfig.imageUploadCloudinary(trustCompanies.getImage(), null));
        firebaseServices.saveFirebase(trustCompanies, ref, trustCompanies.getKey());

        return "admin";
    }
}
