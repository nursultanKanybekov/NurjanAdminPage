package com.nurjan.admin.controller;

import com.nurjan.admin.model.ExperienceModel;
import com.nurjan.admin.model.FeedBackModel;
import com.nurjan.admin.model.InterestedIn;
import com.nurjan.admin.model.PortfolyoModel;
import com.nurjan.admin.service.FirebaseServices;
import com.nurjan.admin.service.StringService;
import com.nurjan.admin.service.TelegramBotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
public class MainPage {
    @Autowired
    FirebaseServices firebaseServices;
    private final StringService stringService = new StringService();

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String mainPageG(Model model) throws ExecutionException, InterruptedException {
        showSkill(model);
        showTrustCompanies(model);
        showFeedback(model);
        showInterestedIn(model);
        showPortfolyo(model);
        showExperience(model);
        return "main";
    }

    private void showExperience(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> experience = firebaseServices.getOptionsFromFirebase("experience");
        List<String> values = stringService.listToString(experience.get());
        List<ExperienceModel> experienceModels = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            String[] certificates = values.get(i).split("=");
            String[] year = values.get(++i).split("=");
            String[] company = values.get(++i).split("=");
            String[] position = values.get(++i).split("=");
            i++;
            experienceModels.add(new ExperienceModel(year[1], company[1], position[1], certificates[1]));
        }
        model.addAttribute("experienceModels", experienceModels);
    }

    private void showPortfolyo(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> portfolyo = firebaseServices.getOptionsFromFirebase("portfolyo");
        List<String> values = stringService.listToString(portfolyo.get());
        List<PortfolyoModel> portfolyoModels = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            String[] image = values.get(i).split("=");
            String[] link = values.get(++i).split("=");
            String[] name = values.get(++i).split("=");
            String[] des = values.get(++i).split("=");
            String[] type = values.get(++i).split("=");
            ++i;
            portfolyoModels.add(new PortfolyoModel(name[1], image[1], link[1], type[1], des[1]));
        }
        model.addAttribute("portfolyoModels", portfolyoModels);
    }

    private void showInterestedIn(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> interested = firebaseServices.getOptionsFromFirebase("interestedIn");
        List<String> values = stringService.listToString(interested.get());
        List<InterestedIn> interestedIn = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            String[] link = values.get(i).split("=");
            String[] des = values.get(++i).split("=");
            String[] type = values.get(++i).split("=");
            ++i;
            interestedIn.add(new InterestedIn(type[1], des[1], link[1]));
        }
        model.addAttribute("interestedIn", interestedIn);
    }

    private void showFeedback(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> feedback = firebaseServices.getOptionsFromFirebase("feedback");
        List<String> values = stringService.listToString(feedback.get());
        List<FeedBackModel> feedBackModels = new ArrayList<>();

        for (int i = 0; i < values.size(); i++) {
            String[] feedbackString = values.get(i).split("=");
            String[] image = values.get(++i).split("=");
            String[] name = values.get(++i).split("=");
            ++i;
            feedBackModels.add(new FeedBackModel(image[1], name[1], feedbackString[1]));
        }

        model.addAttribute("feedbackList", feedBackModels);

    }

    private void showTrustCompanies(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> skill = firebaseServices.getOptionsFromFirebase("trust_companies");
        List<String> values = stringService.listToString(skill.get());
        List<String> linkList = new ArrayList<>();
        List<String> imageList = new ArrayList<>();

        for (String s : values) {
            String[] value = s.split("=");
            if (value[0].equals(" link"))
                linkList.add(value[1]);
            else if (value[0].equals("image"))
                imageList.add(value[1]);
        }
        model.addAttribute("linkList", linkList);
        model.addAttribute("imageList", imageList);
    }

    private void showSkill(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> skill = firebaseServices.getOptionsFromFirebase("skill");
        List<String> values = stringService.listToString(skill.get());
        List<String> android = new ArrayList<>();
        List<String> game = new ArrayList<>();
        List<String> fullStack = new ArrayList<>();
        List<String> softSkill = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            int tempI = i;
            String[] typeChecker = values.get(i).split("=");
            if (typeChecker[0].equals(" type")) {
                String[] skillChecker = values.get(--tempI).split("=");
                switch (typeChecker[1]) {
                    case "android" -> android.add(skillChecker[1]);
                    case "soft" -> fullStack.add(skillChecker[1]);
                    case "game" -> game.add(skillChecker[1]);
                    default -> softSkill.add(skillChecker[1]);
                }
            }
        }
        model.addAttribute("skillsAndroid", android);
        model.addAttribute("skillsFullStack", fullStack);
        model.addAttribute("skillsGameDev", game);
        model.addAttribute("softSkills", softSkill);
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String mainPageP(@RequestParam(defaultValue = "") String contact, @RequestParam(defaultValue = "") String name,
                            @RequestParam(defaultValue = "") String social_media, @RequestParam(defaultValue = "") String message) {
        TelegramBotService telegramBotService = new TelegramBotService();
        if (!contact.equals(""))
            telegramBotService.sendMessage(667621439L, "Из сайта, по поводу работы в нашей компании " + contact);
        else
            telegramBotService.sendMessage(667621439L, "Из сайта! Имя: " + name + ", social media: "
                    + social_media + ", message: " + message);
        return "main";
    }

}
