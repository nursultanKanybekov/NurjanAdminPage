package com.nurjan.admin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

@Controller
public class RSUBD {
    @RequestMapping(value = "/RSUBD", method = RequestMethod.GET)
    public String rsubdG() {
        return "rsubd";
    }

    @RequestMapping(value = "/RSUBD", method = RequestMethod.POST)
    public String rsubdP(@RequestParam(defaultValue = "") String name, @RequestParam(defaultValue = "") String surname,
                         @RequestParam(defaultValue = "") String gpa, @RequestParam(defaultValue = "") String group) {
        String path = "C:\\Users\\nursu\\OneDrive\\Masaüstü\\bilgisayar\\RSUBD_DB\\checker.txt";

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path));
            writer.write(name);
            writer.newLine();
            writer.write(surname);
            writer.newLine();
            writer.write(gpa);
            writer.newLine();
            writer.write(group);
            writer.newLine();
            writer.write("s");
            writer.close();

        } catch (IOException e) {
            // Handle exceptions, such as file not found or permission issues
            e.printStackTrace();
        }
        return "rsubd";
    }
}
