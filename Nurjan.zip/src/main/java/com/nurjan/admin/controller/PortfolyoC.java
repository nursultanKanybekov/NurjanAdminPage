package com.nurjan.admin.controller;

import com.nurjan.admin.model.PortfolyoModel;
import com.nurjan.admin.service.FirebaseServices;
import com.nurjan.admin.service.StringService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
public class PortfolyoC {
    @Autowired
    FirebaseServices firebaseServices;
    private final StringService stringService = new StringService();

    @RequestMapping(value = "/portfolyo", method = RequestMethod.GET)
    public String portfolyo(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> portfolyo = firebaseServices.getOptionsFromFirebase("portfolyo");
        List<String> values = stringService.listToString(portfolyo.get());
        List<PortfolyoModel> portfolyoModels = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            String[] image = values.get(i).split("=");
            String[] link = values.get(++i).split("=");
            String[] name = values.get(++i).split("=");
            String[] des = values.get(++i).split("=");
            String[] type = values.get(++i).split("=");
            ++i;
            portfolyoModels.add(new PortfolyoModel(name[1], image[1], link[1], type[1], des[1]));
        }
        model.addAttribute("portfolyoModels", portfolyoModels);
        return "portfolio";
    }
}
