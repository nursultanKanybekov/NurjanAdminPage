package com.nurjan.admin.controller;

import com.nurjan.admin.service.FirebaseServices;
import com.nurjan.admin.service.StringService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
public class CertificatesC {
    @Autowired
    FirebaseServices firebaseServices;
    StringService stringService = new StringService();

    @RequestMapping(value = "/certificates", method = RequestMethod.GET)
    public String certificates(Model model) throws ExecutionException, InterruptedException {
        CompletableFuture<List<Object>> experience = firebaseServices.getOptionsFromFirebase("experience");
        List<String> values = stringService.listToString(experience.get());
        List<String> certificateLinks = new ArrayList<>();
        for (String value : values) {
            String[] checkerLink = value.split("=");
            if (checkerLink[0].equals("certificates"))
                certificateLinks.add(checkerLink[1]);
        }
        model.addAttribute("certificates", certificateLinks);
        return "certificates";
    }
}
