package com.nurjan.admin.service;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;

import java.io.IOException;
import java.util.Map;

public class CloudinaryService {

    private final Cloudinary cloudinary;
    private final Map params = ObjectUtils.asMap(
            "folder", "nursPortfolyo",
            "resource_type", "auto"
    );

    public CloudinaryService() {
        cloudinary = new Cloudinary(ObjectUtils.asMap(
                "cloud_name", "dpkxkjwmy",
                "api_key", "163832694684664",
                "api_secret", "YDYzDLzJaQIa4mghVhvX96tLXZk"));
    }

    public String imageUploadCloudinary(String link, byte[] file) {
        try {
            Map result;
            if (file == null)
                result = cloudinary.uploader().upload(link, params);
            else
                result = cloudinary.uploader().upload(file, params);
            return (String) result.get("url");
        } catch (IOException exception) {
            return link;
        }

    }
}
