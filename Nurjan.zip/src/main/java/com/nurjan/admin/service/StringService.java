package com.nurjan.admin.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringService {
    public List<String> listToString(List<Object> objects) {
        List<String> allResults = new ArrayList<>();
        for (Object o : objects) {
            String[] result = o.toString().replace("{", "").replace("}", "").split(",");
            allResults.addAll(List.of(result));
        }
        return allResults;
    }
}
