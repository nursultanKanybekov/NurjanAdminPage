package com.nurjan.admin.service;

import com.google.firebase.database.*;
import com.nurjan.admin.config.FirebaseConfig;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class FirebaseServices extends FirebaseConfig {

    // Метод для удаления значения по ключу из базы данных Firebase
    public void deleteTargetValue(String targetValue, String type) {
        // Инициализация Firebase Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        // Получение ссылки на родительский узел, содержащий удаляемое значение
        DatabaseReference ref = database.getReference(type);

        // Создание карты с полем, которое нужно удалить, установленным в null
        Map<String, Object> update = new HashMap<>();
        update.put(targetValue, null);

        // Обновление узла для удаления поля
        ref.updateChildren(update, (databaseError, databaseReference) -> System.out.println("Deleted"));
    }

    // Метод для получения опций из базы данных Firebase
    public CompletableFuture<List<Object>> getOptionsFromFirebase(String nodeName) {
        List<Object> options = new ArrayList<>();
        CompletableFuture<List<Object>> future = new CompletableFuture<>();
        DatabaseReference parentNodeReference = FirebaseDatabase.getInstance().getReference(nodeName);
        parentNodeReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Iterate through the child nodes to retrieve all values
                for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                    Object data = childSnapshot.getValue();

                    options.add(data);
                }
                future.complete(options);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle any errors
                future.completeExceptionally(databaseError.toException());
            }
        });

        return future;
    }


    //     Метод для сохранения данных в базе данных Firebase
    public void saveFirebase(Object user, DatabaseReference ref, String key) {
        // Save the user object with the generated key
        ref.child(key).setValueAsync(user);
    }
}
