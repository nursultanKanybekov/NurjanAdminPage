package com.nurjan.admin.service;

import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

@Component
public class TelegramBotService extends TelegramLongPollingBot {

    @Override
    public String getBotUsername() {
        return "nurskanyb_bot";
    }

    @Override
    public String getBotToken() {
        return "6572062819:AAHF-jY3TzGKBDIGMk0QtwXhF8wsNPrwHRA";
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            sendMessage(update.getMessage().getChatId(), update.getMessage().getText());
        }
    }

    public void sendMessage(Long chatId, String text) {
        SendMessage message = new SendMessage(chatId.toString(), text);
        try {
            execute(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
